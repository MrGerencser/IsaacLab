# Asset Converter

## 1.0 Overview

### 1.1 Introduction

The Asset Converter extension (omni.kit.asset_converter) provides interfaces to convert common 3D formats, like, FBX, OBJ, GLTF, and etc, to USD and also supports to convert USD to those assets.

Most applications such as USD Explorer, Isaac Sim, and Kit-app-template include the Asset Converter extension enabled by default.

### 1.2 System Requirements

To run Omniverse Kit and Omniverse Kit Apps, users must follow the below technical requirements.

Driver Version Requirements:
| Driver Version Support | Windows                                                    | Linux                                                 |
| ---------------------- | ---------------------------------------------------------- | ----------------------------------------------------- |
| Recommended            | 537.58 (GameReady, Studio), 537.70 (RTX/Quadro, Grid/vGPU) | 535.129.03 (GameReady, Studio, RTX/Quadro, Grid/vGPU) |
| Minimum                | 473.47                                                     | 470.182                                               |
| Unsupported            | 495.0 up to 512.59, 525 up to 526.91                       | 495.0 up to 510.58, 515.0 up to 515.17                |


Suggested Minimums by Product:
| Product | Supported Operating Systems | Min CPU: (intel/amd) | Min Ram | Min GPU | Min Disk |
| --- | --- | --- | --- | --- | --- |
| Kit | <ul><li>Windows 10/11</li><li>Ubuntu 20.04/22.04</li><li>CentOS 7</li></ul> | <ul><li>Intel i7 Gen 5</li><li>AMD Ryzen</li></ul> | 16GB | GeForce RTX 3070 | 250GB |
| <ul><li>USD Presenter</li><li>USD Composer</li><li>USD Explorer</li></ul> | <ul><li>Windows 10/11</li><li>Ubuntu 20.04/22.04</li><li>CentOS 7</li></ul> | <ul><li>Intel i7 Gen 5</li><li>AMD Ryzen</li></ul> | 16GB | GeForce RTX 3070 | 250GB |


Please consult Omniverse documentation for details on technical requirements: https://docs.omniverse.nvidia.com/materials-and-rendering/latest/common/technical-requirements.html


### 1.3 Formats and Features Supported

- Supports OBJ/FBX/glTF to USD and USD to those formats. Asset converter will fallback into Assimp if the format is not recognized. So all formats that are supported by Assimp should be supported too. But only OBJ/FBX/glTF are mainly supported and tested.
- Supports both glTF (text) and glb (binary) with/without embedding textures.
- Supports imports of meshes, cameras, and point/sphere/distance/rect light types import and export.
- Supports rigid and skeletal animations.
- Supports to convert glTF materials into MDL with extensions KHR_materials_pbrSpecularGlossiness, KHR_materials_clearcoat, KHR_draco_mesh_compression, KHR_texture_transform, KHR_materials_volume, KHR_materials_emissive_strength, KHR_materials_ior, KHR_materials_sheen, KHR_materials_transmission.
- Supports export baked MDL option (`AssetConverterContext.bake_mdl_material`) which tries to use MDL Distilling to distill and bake MDL materials to UsdPreviewSurface.
- Supports direct import/export of MDL material graphs to/from glTF with the NV_materials_mdl extension.

**_NOTE:_** SolidWorks, STL, Autodesk Inventor, AutoCAD 3D, Creo, Revit, Solid Edge, Step, Iges, JT, and DGN formats are supported by CAD Converter and also available by default. More details of CAD Converter can be found at: https://docs.omniverse.nvidia.com/kit/docs/omni.kit.converter.cad/latest/Overview.html#formats-and-features-supported

### 1.4 Supported Material Parameters

Supported material parameters by each importer is described in this table.

|              | ASSIMP | FBX | glTF | OBJ  |
| ---          | ---    | --- | ---  | ---  |
| DIFFUSE      |     o  |   o |    o |   o  |
| EMISSIVE     |     o  |   o |    o |   o  |
| OPACITY      |     o  |   o |    o |   o  |
| NORMAL       |     o  |   o |    o |   o  |
| SPECULAR     |     o  |   o |    o |      |
| GLOSSY       |     o  |     |    o |      |
| OCCLUSION    |     o  |   o |    o |      |
| ROUGHNESS    |     o  |   o |    o |    o |
| METALLIC     |     o  |   o |    o |    o |
| CLEARCOAT    |     o  |     |    o |      |
| TRANSMISSION |     o  |     |    o |      |
| SHEEN        |     o  |     |    o |      |

Supported material parameters by each exporter is described in this table.
|              | ASSIMP | FBX | glTF |
| ---          | ---    | --- | ---  |
| DIFFUSE      |      o |   o |    o |
| EMISSIVE     |      o |   o |    o |
| OPACITY      |      o |   o |    o |
| NORMAL       |      o |   o |    o |
| SPECULAR     |      o |     |    o |
| GLOSSY       |      o |     |    o |
| OCCLUSION    |      o |     |    o |
| ROUGHNESS    |      o |     |    o |
| METALLIC     |      o |     |    o |
| CLEARCOAT    |      o |     |    o |
| TRANSMISSION |      o |     |    o |
| SHEEN        |      o |     |    o |
| AMBIENT      |        |   o |      |
| DISPLACEMENT |        |   o |      |

### 1.5 Known Issues and Unsupported

- It does not support recursive skeleton for glTF.
- Only OmniPBR, OmniGlass, UsdPreviewSurface, and specified gltf.mdl are supported for exporting USD to other formats.

### 1.6 Getting Help

Enterprise Customers can report Omniverse issues here: https://www.nvidia.com/en-us/omniverse/enterprise/support/
Alternatively, uses can also report Omniverse issues on NVIDIA forums:  https://forums.developer.nvidia.com/t/how-to-report-an-issue-with-omniverse/199675


## 2.0 Usage UI/UX

The Asset Converter extension is available on builds of USD Composer, USD Explorer, and Isaac Sim. To obtain any of these Omniverse Apps, go to https://docs.omniverse.nvidia.com/launcher/latest/overview.html for steps to download and install the Omniverse Launcher. The Omniverse Launcher provides access and installs Omniverse Apps.

### 2.1 Omniverse Apps Import Functionality

To begin conversion of an asset, open any one of these three Omniverse Apps. The user can then import the file into Omniverse as a USD file through the File menu or through the Content window.

### 2.1.1 Import through the File menu

To import a CAD file into Omniverse, choose `Import` in the `File` menu. Use this method to import CAD Data into your scene - either by reference or directly into your stage.

![File Import](./images/file-import.png "File Import")

### 2.1.2 Begin "Import" through the Content Window
By default the Content window is located at the bottom of the Omniverse App. It contains panels for showing a tree hierarchy of the user's file system along with icon or list representation of the files in the currently open folder. If it is not shown, go to the toolbar, select "Window", and then select "Content". To convert a CAD file to USD, select the file in the Content window and choose `Convert to USD` in the context menu with right mouse button.

![Convert to USD](./images/convert-to-usd.png "Convert to USD")

### 2.2 Selecting a File for Import

The user should now see a window similar to a file manager. The user needs to then select an asset for conversion from this window.
When a supported file has been selected, the user should see a panel on the right-side of the window like below and update the import options as desired:

![Import Window](./images/import-window.png "Import Window")

### 2.3 Import through drag and drop

The user also has the option to drag and drop assets into the application from Content Window or File Browser to convert them. The supported file formats will be recognized and processed appropriately.

![Drag and Drop](./images/drag-and-drop.png "Drag and Drop")

## 3.0 Programming Guide

```python
"""
This is the simple sample that utilizes omni.kit.asset_converter to convert assets.
"""

import asyncio
import omni.kit.asset_converter

def progress_callback(current_step: int, total: int):
    # Show progress
    print(f"{current_step} of {total}")

async def convert(input_asset_path, output_asset_path):
    task_manager = converter.get_instance()
    task = task_manager.create_converter_task(input_asset_path, output_asset_path, progress_callback)
    success = await task.wait_until_finished()
    if not success:
        detailed_status_code = task.get_status()
        detailed_status_error_string = task.get_error_message()
        ...

...
asyncio.ensure_future(convert(input_path, output_path))
...
```

**create_converter_task** supports a fourth param omni.kit.asset_converter.AssetConverterContext, which you can use to customize the import/export. By default, it will import/export all supported props. Following is its definition:

```python
class AssetConverterContext:
    ignore_materials = False    # Don't import/export materials
    ignore_animations = False   # Don't import/export animations
    ignore_camera = False       # Don't import/export cameras
    ignore_light = False        # Don't import/export lights
    single_mesh = False         # By default, instanced props will be export as single USD for reference. If
                                # this flag is true, it will export all props into the same USD without instancing.
    smooth_normals = True       # Smoothing normals, which is only for assimp backend.
    export_preview_surface = False      # Imports material as UsdPreviewSurface instead of MDL for USD export
    support_point_instancer = False     # Deprecated
    embed_mdl_in_usd = True     # Deprecated.
    use_meter_as_world_unit = False     # Sets world units to meters, this will also scale asset if it's centimeters model.
    create_world_as_default_root_prim = True    # Creates /World as the root prim for Kit needs.
    embed_textures = True   # Embedding textures into output. This is only enabled for FBX and glTF export.
    convert_fbx_to_y_up = False   # Always use Y-up for fbx import.
    convert_fbx_to_z_up = False   # Always use Z-up for fbx import.
    keep_all_materials = False    # If it's to remove non-referenced materials.
    merge_all_meshes = False      # Merges all meshes to single one if it can.
    use_double_precision_to_usd_transform_op = False   # Uses double precision for all transform ops.
    ignore_pivots = False         # Don't export pivots if assets support that.
    disabling_instancing = False  # Don't export instancing assets with instanceable flag.
    export_hidden_props = False   # By default, only visible props will be exported from USD exporter.
    baking_scales = False         # Only for FBX. It's to bake scales into meshes.
    ignore_flip_rotations = False # Don't ignore animation's flip rotation value.
    ignore_unbound_bones = False  # Only for FBX. Don't ignore unbound bones.
    bake_mdl_material = False     # Bake mdl material when export
    export_separate_gltf = False  # Export gltf with separate bin file if true, else export one standalone gltf.
    export_mdl_gltf_extension = False # Only for glTF. Export materials as NV_materials_mdl extension materials.
    convert_stage_up_y = False   # Set stage up-axis to y-up.
    convert_stage_up_z = False   # Set stage up-axis to z-up.

```