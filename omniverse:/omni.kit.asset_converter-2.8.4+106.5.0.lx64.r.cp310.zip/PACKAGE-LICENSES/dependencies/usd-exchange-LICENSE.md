NVIDIA OpenUSD Exchange SDK is governed by the following NVIDIA Agreements:

Enterprise Software | NVIDIA Software License Agreement and NVIDIA Agreements
https://www.nvidia.com/en-us/agreements/enterprise-software/nvidia-software-license-agreement/

and

NVIDIA Agreements | Enterprise Software | Product Specific Terms for Omniverse
https://www.nvidia.com/en-us/agreements/enterprise-software/product-specific-terms-for-omniverse

By downloading or using NVIDIA OpenUSD Exchange SDK, you agree to the NVIDIA Omniverse terms.
